/*
  compute the dominance frontier of a graph
*/
#include "Graph.h"

int main()
{
  Graph graph("Input.txt");
  return 0;
}

