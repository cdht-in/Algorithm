g++ -std=c++11 -g Graph.cpp DominanceFrontier.cpp && ./a.out
